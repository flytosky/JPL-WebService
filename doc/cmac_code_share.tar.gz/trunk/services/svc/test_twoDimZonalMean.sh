#!/bin/bash
curl "http://cmacws.jpl.nasa.gov:8090/svc/twoDimZonalMean?model=UKMO_HadGEM2-ES&var=ts&start_time=199001&end_time=199512&lat1=-29&lat2=29&months=1,2,3,4,5,6,7,8,9,10,11,12"
