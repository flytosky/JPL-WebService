#!/bin/bash
curl "http://cmacws.jpl.nasa.gov:8090/svc/timeSeries2D?model=ukmo_hadgem2-a&var=clt&start_time=199001&end_time=199512&lon1=0&lon2=100&lat1=0&lat2=20"
