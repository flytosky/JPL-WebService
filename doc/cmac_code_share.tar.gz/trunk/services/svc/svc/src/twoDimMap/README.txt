. Sample input arguments:
  ./octaveWrapper ukmo_hadgem2-a ts 199001 199512 '0, 100' '-29,29' '4,5,6,10,12' .
