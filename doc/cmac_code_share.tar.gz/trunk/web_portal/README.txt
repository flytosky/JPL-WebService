How to deploy this CMAC web portal:

. put this dir and subdirs to DocumentRoot of Apache2
. on ubuntu, this is done by editing
  /etc/apache2/sites-available/default
. change urls where applicable under web_portal/cmac
