<!-- Footer, Only Parts that can be modified are indicated -->
	<div id="footer">
		<div class="usa_gov">&nbsp;</div>
			<div class="footer_credits">
            
            
<p>Site Manager: <a href="mailto:lei.pan@jpl.nasa.gov">Lei Pan</a><br/> JPL Clearance: CL#13-1931</p>

  			</div>
  						<div class="footer_nav"><p><a href="http://www.jpl.nasa.gov/copyrights.cfm">PRIVACY</a> &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;<a href="http://www.jpl.nasa.gov/imagepolicy/">IMAGE POLICY</a></p>
 						 </div><div class="clear"></div>
						</div>
<!-- end #footer -->
</div>
