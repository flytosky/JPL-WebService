<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>CMAC Services</title>
<link href="css/main.css" rel="stylesheet" type="text/css" />
<link href="css/print.css" rel="stylesheet" type="text/css" media="print"/>
<link href="css_oscar/style.css" rel="stylesheet" type="text/css"/>

<!-- Begin RSS feed -->
<?php include 'includes/rssfeed.php'; ?>
<!-- End RSS feed -->

<!-- oscar js start fixme: it should depend on the name of calling php script -->
<!-- <script type="text/javascript" src="./index.js"></script> -->
<!-- oscar js end -->

</head>

<!-- oscar body start -->
<!-- <body onload="oscar.init()"> -->
<!-- oscar body end -->

<!-- Top Navigation Banner #wrapper_top -->
<div id="wrapper_top">
<?php include 'includes/headerNoNav.php'; ?>
</div>
<!-- end #wrapper_top -->

<div id="wrapper_middle_2">
	<div id="middle_2_border">

<!--*Note: This page uses the following font format throughout the body using the external CSS stylesheet(included): 
font-family: Helvetica, Arial, Verdana, sans-serif; color: #4b5c68;-->

       <div id="inner_body_content">
<!-- Add Main Content Below Here -->

<!-- oscar content starts -->

<div style="padding:10px; font-size:1.5em"> <!-- oscar font change starts -->

<TABLE ALIGN="CENTER" WIDTH="900" HEIGHT="300" BORDER="0" CELLPADDING="0" CELLSPACING="0">

<!-- oscar banner -->

<!-- <tr><td colspan="2" width="730" height="100" background="./image_oscar/banner.jpg" border="0"></td></tr> -->

<!-- <TR><TD COLSPAN=2>&nbsp;</TD></TR> -->

<TR><TD COLSPAN="2" HEIGHT="100%" VALIGN="TOP">

<table border="0" width=100% cellpadding="2" cellspacing="1">

<tr valign="top" bgcolor="#fffff">
<!-- <td width="20%"> -->
<td width="0%">
<?php require_once('./menu.php') ?>
</td>
<td>

